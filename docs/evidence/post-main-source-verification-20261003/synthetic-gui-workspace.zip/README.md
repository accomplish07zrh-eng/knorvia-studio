# Synthetic GUI workspace
Only generated acceptance data.
