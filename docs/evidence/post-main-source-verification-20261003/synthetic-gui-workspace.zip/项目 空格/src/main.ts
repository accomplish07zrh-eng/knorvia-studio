export const syntheticLabel = "KNORVIA_GUI_SEARCH_20261003";
